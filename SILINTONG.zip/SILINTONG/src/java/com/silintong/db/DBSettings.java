/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.silintong.db;

/**
 *
 * @author juan.karsten
 */
public class DBSettings {
    public static String USER="root";
    public static String PASSWORD="";
    public static String URL="jdbc:mysql://localhost/silintong";
}
